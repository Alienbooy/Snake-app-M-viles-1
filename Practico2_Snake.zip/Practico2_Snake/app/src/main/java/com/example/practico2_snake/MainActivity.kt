package com.example.practico2_snake

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var snakeView: SnakeView
    private val handler = Handler(Looper.getMainLooper())
    private val gameloop = object :Runnable {
        override fun run() {
            snakeView.update()
            snakeView.invalidate()
            handler.postDelayed(this, 300)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        snakeView = findViewById(R.id.snakeView)
        starGameLoop()
    }

    private fun starGameLoop() {
        handler.post(gameloop)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(gameloop)
    }
}
