package com.example.practico2_snake

import android.content.Context
import android.content.res.Resources
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.random.Random

class SnakeView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val snake = mutableListOf<Pair<Int, Int>>() // UNA LISTA MUTABLE PARA LA SNAKE QUE DICE LAS CORDENADAS
    private var direction = Direction.RIGHT // COMO VA COMENZAR
    private var applePosition = Pair(0, 0)
    private val paintSnake = Paint().apply { color = Color.BLACK }
    private val paintApple = Paint().apply { color = Color.RED }
    private val gridSize = 40 // TAMAÑO DE LOS PIXELES
    private var boardWidth = 0// DIMENSION DE LA MATRIZ DEPENDIENDO DE LA PANTALLA
    private var boardHeight = 0

    init {
        // Obtener el tamaño de la pantalla y calcular el número de celdas
        val displayMetrics = Resources.getSystem().displayMetrics
        boardWidth = displayMetrics.widthPixels / gridSize // columnas en el ancho
        boardHeight = displayMetrics.heightPixels / gridSize // filas  en el alto
        resetGame()
    }

    private fun resetGame() {

        snake.clear()
        snake.add(Pair(boardWidth / 2, boardHeight / 2))
        direction = Direction.RIGHT
        spawnApple()
    }

    private fun spawnApple() {

        do {
            applePosition = Pair(Random.nextInt(boardWidth), Random.nextInt(boardHeight))
        } while (applePosition in snake)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val paintUp = Paint().apply { color = Color.BLUE }
        val paintDown = Paint().apply { color = Color.MAGENTA }
        val paintLeft = Paint().apply { color = Color.GREEN }
        val paintRight = Paint().apply { color = Color.LTGRAY }

        val pantallaAncho = width
        val pantallaAlto = height

        // Dibujo de colores del movimiento de la vivorita
        // banda superior de color azul
        canvas.drawRect(0f, 0f, pantallaAncho.toFloat(), (pantallaAlto / 4).toFloat(), paintUp)
        // Área inferior
        canvas.drawRect(0f, (pantallaAlto - pantallaAlto / 4).toFloat(), pantallaAncho.toFloat(), pantallaAlto.toFloat(), paintDown)
        // bloque de la izquierda de color verde
        canvas.drawRect(0f, (pantallaAlto / 4).toFloat(), (pantallaAncho / 2).toFloat(), (pantallaAlto - pantallaAlto /4).toFloat(), paintLeft)
        // bloque de la derecha de color gris
        canvas.drawRect((pantallaAncho / 2).toFloat(), (pantallaAlto / 4).toFloat(), pantallaAncho.toFloat(), (pantallaAlto - pantallaAlto / 4).toFloat(), paintRight)
        canvas?.let {
            // Draw snake
            for (segment in snake) {
                it.drawRect(
                    segment.first * gridSize.toFloat(),
                    segment.second * gridSize.toFloat(),
                    (segment.first + 1) * gridSize.toFloat(),
                    (segment.second + 1) * gridSize.toFloat(),
                    paintSnake
                )
            }
            // Draw apple
            it.drawRect(
                applePosition.first * gridSize.toFloat(),
                applePosition.second * gridSize.toFloat(),
                (applePosition.first + 1) * gridSize.toFloat(),
                (applePosition.second + 1) * gridSize.toFloat(),
                paintApple
            )
        }
    }

    fun update() {
        moveSnake()
        checkCollisions()
        invalidate() // Redraw the view
    }

    private fun moveSnake() {
        val head = snake.first()
        var newHead = head
        when (direction) {
            Direction.UP -> newHead = Pair(head.first, (head.second - 1 + boardHeight) % boardHeight)
            Direction.DOWN -> newHead = Pair(head.first, (head.second + 1) % boardHeight)
            Direction.LEFT -> newHead = Pair((head.first - 1 + boardWidth) % boardWidth, head.second)
            Direction.RIGHT -> newHead = Pair((head.first + 1) % boardWidth, head.second)
        }
        snake.add(0, newHead)
        if (newHead == applePosition) {

            spawnApple()
        } else {

            snake.removeLast()
        }
    }

    private fun checkCollisions() {
        val head = snake.first()
        if (snake.drop(1).contains(head)) {
            resetGame()
        }
    }


    override fun onTouchEvent(event: MotionEvent?): Boolean {
        event?.let {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    val x = event.x
                    val y = event.y

                    //divido la pantalla en 4 partes
                    val pantallaAncho = width
                    val pantallaAlto = height

                    // sus cordenadas
                    val topAreaAlto = pantallaAlto / 4
                    val bottomAreaAlto = pantallaAlto - pantallaAlto / 4
                    val centradoAreaAncho = pantallaAncho / 2


                    when {
                        y <= topAreaAlto && direction != Direction.DOWN -> {
                            direction = Direction.UP
                        }
                        y >= bottomAreaAlto && direction != Direction.UP -> {
                            direction = Direction.DOWN
                        }
                        x <= centradoAreaAncho && y > topAreaAlto && y < bottomAreaAlto && direction != Direction.RIGHT -> {
                            direction = Direction.LEFT
                        }
                        x > centradoAreaAncho && y > topAreaAlto && y < bottomAreaAlto && direction != Direction.LEFT -> {
                            direction = Direction.RIGHT
                        }
                    }
                }
            }
        }
        return true
    }
}

