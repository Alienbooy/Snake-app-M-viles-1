package com.example.practico2_snake

enum class Direction {
    UP, DOWN, LEFT, RIGHT
}